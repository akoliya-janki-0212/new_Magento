<?php
class Practice_Test_Model_Test2 extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('practice_test/test2');
    }
}

?>